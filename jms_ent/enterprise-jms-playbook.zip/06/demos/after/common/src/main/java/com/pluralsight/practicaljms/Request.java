package com.pluralsight.practicaljms;

/**
 * Created by Grant Little grant@grantlittle.me
 */
public class Request {
    private int id = 0;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
